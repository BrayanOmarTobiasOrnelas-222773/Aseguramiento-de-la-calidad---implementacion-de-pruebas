<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Casos Manuales</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>58eb1355-4812-4b93-ac58-d713d7999ba6</testSuiteGuid>
   <testCaseLink>
      <guid>bcc9b088-413c-486e-bc62-08e91df5ac0b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Casos Manuales/Cierre de Sesion</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    