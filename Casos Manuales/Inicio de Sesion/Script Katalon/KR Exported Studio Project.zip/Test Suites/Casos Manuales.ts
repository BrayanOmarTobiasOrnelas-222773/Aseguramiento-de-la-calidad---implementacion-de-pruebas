<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Casos Manuales</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>58eb1355-4812-4b93-ac58-d713d7999ba6</testSuiteGuid>
   <testCaseLink>
      <guid>811f2a11-712c-49a4-b1ff-aeb50a89dfb5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Casos Manuales/Inicio de Sesion</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    